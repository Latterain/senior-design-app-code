package com.wuchen.skywalker;

import com.wuchen.skywalker.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;

public class LightActivity extends Activity {

	public static String LIGHT_SETTING = "light_setting";
	RadioButton lightOnButton;
	RadioButton lightOffButton;
	RadioButton lightAutoButton;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.light);
        lightOnButton = (RadioButton) findViewById(R.id.radioLightOn);
        lightOffButton = (RadioButton) findViewById(R.id.radioLightOff);
        lightAutoButton = (RadioButton) findViewById(R.id.radioLightAuto);
        Button saveButton = (Button) findViewById(R.id.lightSavebutton);
        Button cancelButton = (Button) findViewById(R.id.lightCancelbutton);
        // click 事件
        saveButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                if (lightOnButton.isChecked()) intent.putExtra(LIGHT_SETTING, "1");
                if (lightOffButton.isChecked()) intent.putExtra(LIGHT_SETTING, "2");
                if (lightAutoButton.isChecked()) intent.putExtra(LIGHT_SETTING, "3");
            	setResult(Activity.RESULT_OK, intent);
            	finish();
            }
        });
        cancelButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                setResult(Activity.RESULT_CANCELED);
                finish();
            }
        });
    }
}
