package com.wuchen.skywalker;

import com.wuchen.skywalker.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.Preference.OnPreferenceChangeListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class SettingsActivity extends Activity {

	public static String MAX_POWER = "max_power";
	
	TextView maxPowerTxt;
	SeekBar maxPowerBar;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting);
        Button saveButton = (Button) findViewById(R.id.savebutton);
        Button cancelButton = (Button) findViewById(R.id.cancelbutton);
        maxPowerBar = (SeekBar) findViewById(R.id.max_power_bar);
        maxPowerTxt = (TextView) findViewById(R.id.max_power_txt);
        // 拖动事件
        maxPowerBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            	maxPowerTxt.setText("动力比例设置："+progress+"%");
            }
        });
        // click 事件
        saveButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.putExtra(MAX_POWER, Integer.toString(maxPowerBar.getProgress()));
            	setResult(Activity.RESULT_OK, intent);
            	finish();
            }
        });
        cancelButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                setResult(Activity.RESULT_CANCELED);
                finish();
            }
        });
    }
}
