/*
 * Copyright (c) 2010 Jacek Fedorynski
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This file is derived from:
 * 
 * http://developer.android.com/resources/samples/BluetoothChat/src/com/example/android/BluetoothChat/BluetoothChatService.html
 * 
 * Copyright (c) 2009 The Android Open Source Project
 */

package com.wuchen.skywalker;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.widget.TextView;
import android.os.Vibrator;


public class NXTTalker {

    public static final int STATE_NONE = 0;
    public static final int STATE_CONNECTING = 1;
    public static final int STATE_CONNECTED = 2;
    
    private int safeTimeDelay = 100; //防止手指误碰的时间
    private long firstTouchTime = 0;  //手指开始碰到屏幕的时间
    private int brakePos = 50;  // 在总行程100中，刹车占的位置比例

    private int mState;
    private Handler mHandler;
    private BluetoothAdapter mAdapter;

    private ConnectThread mConnectThread;
    private ConnectedThread mConnectedThread;
    private int power = 50;
    private TextView powerTextView = null;
    private int prePower = 50;
    private double batteryValue = 0;
    private double batteryScale = 5.444; //电池测量用的电阻比例

    private Handler timerHandle = new Handler();
    private int timerDaly = 100;
    private FileOutputStream fos;
    private Runnable runnable = new Runnable() {
        public void run() {
            long loopStartTime = System.currentTimeMillis();
            if (prePower != power && loopStartTime - firstTouchTime > safeTimeDelay) {
                // prePower = power;
                // 限制每秒钟速度速度变化不超过一定值
                int step = 200;  // 设置的比较大，表示不限制手机上的速度
                if (prePower > power) {
                    prePower = Math.max(prePower - step, power);
                } else {
                    prePower = Math.min(prePower + step, power);
                }
            }
            if (powerTextView != null){
                String displayText = "";
                if (prePower <= brakePos) {
                    int percent = (brakePos - prePower) * 100 / brakePos;
                    displayText = "Brake " + Integer.toString(percent) + "%";
                } else if (prePower <= 100) {
                    int percent = (prePower - brakePos) * 100 / (100 - brakePos);
                    displayText = "Power " + Integer.toString(percent) + "%";
                }
                if (firstTouchTime == 0) {
                    displayText = "Brake 0 - No touch";
                }
                if (batteryValue > 0) {
                    int powerPercent = (int)(100 * (batteryValue / 6 - 3.5) / 0.7);
                    if (powerPercent > 100) powerPercent = 100;
                    if (powerPercent < 0) powerPercent = 0;
                    displayText = "\r\n\r\n" + displayText + "\r\n\r\nButtery:" + Integer.toString(powerPercent) + "% left";
                }
                powerTextView.setText(displayText);
            }
            sendCmd();
            long loopUsedTime = System.currentTimeMillis() - loopStartTime;
            timerHandle.postDelayed(this, Math.max(timerDaly - loopUsedTime, 1));
        }
    };
    
    private void recordLog(String text) {
        if (fos != null) {
            try {
                fos.write(text.getBytes());
            } catch (IOException e) {
            }
        }
    }

    public NXTTalker(Handler handler) {
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mHandler = handler;
        setState(STATE_NONE);
        timerHandle.postDelayed(runnable, timerDaly);
    }

    public void setPowerTextView(TextView view) {
        powerTextView = view;
    }
    
    public void setFOS(FileOutputStream f) {
        fos = f;
    }

    private synchronized void setState(int state) {
        mState = state;
        if (mHandler != null) {
            mHandler.obtainMessage(NXTRemoteControl.MESSAGE_STATE_CHANGE,
                    state, -1).sendToTarget();
        } else {
            // XXX
        }
    }

    public synchronized int getState() {
        return mState;
    }

    public synchronized void setHandler(Handler handler) {
        mHandler = handler;
    }

    public synchronized void connect(BluetoothDevice device) {
        // Log.i("NXT", "NXTTalker.connect()");

        if (mState == STATE_CONNECTING) {
            if (mConnectThread != null) {
                mConnectThread.cancel();
                mConnectThread = null;
            }
        }

        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }

        mConnectThread = new ConnectThread(device);
        mConnectThread.start();
        setState(STATE_CONNECTING);
    }

    public synchronized void connected(BluetoothSocket socket,
            BluetoothDevice device) {
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }

        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }

        mConnectedThread = new ConnectedThread(socket);
        mConnectedThread.start();

        // toast("Connected to " + device.getName());

        setState(STATE_CONNECTED);
    }

    public synchronized void stop() {
        if (mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }

        if (mConnectedThread != null) {
            mConnectedThread.cancel();
            mConnectedThread = null;
        }
        setState(STATE_NONE);
    }

    private void connectionFailed() {
        setState(STATE_NONE);
        // toast("Connection failed");
    }

    private void connectionLost() {
        setState(STATE_NONE);
        // toast("Connection lost");
    }

    public void setCtrlValue(int newValue, int type) {
        if (type == 1) {
            long currentTime = System.currentTimeMillis();
            if (newValue <= 100 && firstTouchTime == 0) {
                firstTouchTime = currentTime; // 手指按下
            }
            if (newValue == 255) {
                firstTouchTime = 0; //手指离开
                power = 50;
                return;
            } else if (newValue > 100 && newValue <= 205){
                // 100~200 设置最大油门比例
                // 201 ~ 203 灯光设置
                // 204 开喇叭，205关喇叭
                sendCmd((byte)255);
                sendCmd((byte)newValue);
                return;
            }        
            power = newValue;
        }
        // sendCmd();
    }

    public int getCtrlValue(int type) {
        if (type == 1) return power;
        return 0;
    }

    public void sendCmd() {
        byte[] data = { (byte) prePower};
        write(data);
    }
    
    public void sendCmd(byte cmd) {
        /*
        if (cmd < 100 && cmd >= 50) {
            cmd = (byte) (cmd * 2 - 100);
        }
        if (cmd < 50) cmd = (byte) 0;*/
        
        byte[] data = {cmd};
        write(data);
    }

    private void write(byte[] out) {
        ConnectedThread r;
        synchronized (this) {
            if (mState != STATE_CONNECTED) {
                return;
            }
            r = mConnectedThread;
        }
        r.write(out);
    }

    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;

        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;
            BluetoothSocket tmp = null;

            try {
                tmp = device.createRfcommSocketToServiceRecord(UUID
                        .fromString("00001101-0000-1000-8000-00805F9B34FB"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            mmSocket = tmp;
        }

        public void run() {
            setName("ConnectThread");
            mAdapter.cancelDiscovery();

            try {
                mmSocket.connect();
            } catch (IOException e) {
                connectionFailed();
                try {
                    mmSocket.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                return;
            }

            synchronized (NXTTalker.this) {
                mConnectThread = null;
            }

            connected(mmSocket, mmDevice);
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final InputStream mmInStream;
        private final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            mmSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            try {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run() {
            byte[] buffer = new byte[1024];

            while (true) {
                try {
                    // 读取电量信息
                    int bytes = mmInStream.read(buffer);
                    if (bytes > 0) {
                        int readBatValue = buffer[bytes - 1];
                        if (readBatValue < 0) readBatValue += 256;
                        batteryValue = batteryScale * 5 * readBatValue / 256;
                    }
                    // toast(Integer.toString(bytes) +
                    // " bytes read from device");
                } catch (IOException e) {
                    e.printStackTrace();
                    connectionLost();
                    break;
                }
            }
        }

        public void write(byte[] buffer) {
            try {
                mmOutStream.write(buffer);
            } catch (IOException e) {
                e.printStackTrace();
                // XXX?
            }
        }

        public void cancel() {
            try {
                mmSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
