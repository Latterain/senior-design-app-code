/*
 * Copyright (c) 2010 Jacek Fedorynski
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * This file is derived from:
 * 
 * http://developer.android.com/resources/samples/BluetoothChat/src/com/example/android/BluetoothChat/BluetoothChat.html
 * 
 * Copyright (c) 2009 The Android Open Source Project
 */

package com.wuchen.skywalker;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import com.wuchen.skywalker.R;

import android.app.Activity;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Vibrator;

public class NXTRemoteControl extends Activity implements OnSharedPreferenceChangeListener {
    
    private boolean NO_BT = false; 
    
    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_CONNECT_DEVICE = 2;
    private static final int REQUEST_SETTINGS = 3;
    private static final int REQUEST_LIGHT = 4;
    
    public static final int MESSAGE_TOAST = 1;
    public static final int MESSAGE_STATE_CHANGE = 2;
    
    public static final String TOAST = "toast";
    
    private static final int MODE_BUTTONS = 1;
    
    private BluetoothAdapter mBluetoothAdapter;
    private NXTTalker mNXTTalker;
    private boolean hornOpen = false;
    
    private int mState = NXTTalker.STATE_NONE;
    private int mSavedState = NXTTalker.STATE_NONE;
    private boolean mNewLaunch = true;
    private String mDeviceAddress = null;
    private TextView mStateDisplay;
    private MenuItem mBluetoothMenu;
    private TextView power_value;
    private Menu mMenu;
    
    private int mPower = 0;
    private boolean inLowPowerArea = true;
    private int mControlsMode = MODE_BUTTONS;
    private FileOutputStream fos;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // 超时控制
        long now = System.currentTimeMillis();
        // 2014/9/1过期
        if (now > java.util.Date.UTC(115, 8, 1, 0, 0, 0)) {
            // System.exit(0);
        }
        
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        readPreferences(prefs, null);
        prefs.registerOnSharedPreferenceChangeListener(this);
        
        if (savedInstanceState != null) {
            mNewLaunch = false;
            mDeviceAddress = savedInstanceState.getString("device_address");
            if (mDeviceAddress != null) {
                mSavedState = NXTTalker.STATE_CONNECTED;
            }
            
            if (savedInstanceState.containsKey("power")) {
                mPower = savedInstanceState.getInt("power");
            }
            if (savedInstanceState.containsKey("controls_mode")) {
                mControlsMode = savedInstanceState.getInt("controls_mode");
            }
        }
        
        if (!NO_BT) {
            mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
       
            if (mBluetoothAdapter == null) {
                Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
                finish();
                return;
            } 
        }
        
        setupUI();
        mNXTTalker = new NXTTalker(mHandler);
        mNXTTalker.setPowerTextView(power_value);
    }

    private void updateMenu(int disabled) {
        if (mMenu != null) {
            mMenu.findItem(R.id.menuitem_buttons).setEnabled(disabled != R.id.menuitem_buttons).setVisible(disabled != R.id.menuitem_buttons);
            //mMenu.findItem(R.id.menuitem_light).setEnabled(disabled != R.id.menuitem_light).setVisible(disabled != R.id.menuitem_light);
            //mMenu.findItem(R.id.menuitem_tank).setEnabled(disabled != R.id.menuitem_tank).setVisible(disabled != R.id.menuitem_tank);
            //mMenu.findItem(R.id.menuitem_tank3motor).setEnabled(disabled != R.id.menuitem_tank3motor).setVisible(disabled != R.id.menuitem_tank3motor);
        }
    }
    
    @Override
    public boolean onTouchEvent (MotionEvent event) {
        switch (event.getAction()) {
        case MotionEvent.ACTION_DOWN: // 手指按下
        case MotionEvent.ACTION_MOVE:  // 手指移动
            int x  = (int)event.getRawX();
            int y = (int)event.getRawY();
            int viewWidth = getWindowManager().getDefaultDisplay().getWidth();
            int viewHeight = getWindowManager().getDefaultDisplay().getHeight();
            if ( 1.0 * x / viewWidth > 0.9) {
                if (!hornOpen) {
                    mNXTTalker.setCtrlValue(204, 1);
                    hornOpen = true;
                }
            } else {
                if (hornOpen) {
                    mNXTTalker.setCtrlValue(205, 1);
                    hornOpen = false;
                }
            }
            int offset = viewHeight / 6; // Use 20% as empty zone 
            int power = 100 - (y - offset) * 100 / (viewHeight - 2 * offset);
            power = Math.min(100, Math.max(0, power));
            mNXTTalker.setCtrlValue(power, 1);
            if ((inLowPowerArea && power > 53) || (!inLowPowerArea && power < 47)) {
                Vibrator mVibrator = (Vibrator)getApplication().getSystemService(Service.VIBRATOR_SERVICE);
                mVibrator.vibrate(200);
                inLowPowerArea = (power < 50);
            }
            break;
        case MotionEvent.ACTION_UP:// 手指抬起
            mNXTTalker.setCtrlValue(255, 1);
            //手指抬起后轻带刹车
            //mNXTTalker.setCtrlValue(50, 1);
            break;
        default:
            break;
        }
        return false;
    }
    
    
    private void setupUI() {
        if (mControlsMode == MODE_BUTTONS) {
            setContentView(R.layout.main);
            updateMenu(R.id.menuitem_buttons);
            power_value = (TextView) findViewById(R.id.power_value);
        }
        mStateDisplay = (TextView) findViewById(R.id.state_display);
        displayState();
    }

    @Override
    protected void onStart() {
        super.onStart();
        //Log.i("NXT", "NXTRemoteControl.onStart()");
        if (!NO_BT) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            } else {
                if (mSavedState == NXTTalker.STATE_CONNECTED) {
                    BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(mDeviceAddress);
                    mNXTTalker.connect(device);
                } else {
                    if (mNewLaunch) {
                        mNewLaunch = false;
                        findBrick();
                    }
                }
            }
        }
        // init file system
        String path = Environment.getExternalStorageDirectory().getPath() + "/board.log";
        try {
            //fos = new FileOutputStream(new File(path));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            Toast.makeText(this, path, Toast.LENGTH_LONG).show();
            fos = null;
        }
        mNXTTalker.setFOS(fos);
    }

    private void findBrick() {
        Intent intent = new Intent(this, ChooseDeviceActivity.class);
        startActivityForResult(intent, REQUEST_CONNECT_DEVICE);
    }
  
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
        case REQUEST_ENABLE_BT:
            if (resultCode == Activity.RESULT_OK) {
                findBrick();
            } else {
                Toast.makeText(this, "Bluetooth not enabled, exiting.", Toast.LENGTH_LONG).show();
                finish();
            }
            break;
        case REQUEST_CONNECT_DEVICE:
            if (resultCode == Activity.RESULT_OK) {
                String address = data.getExtras().getString(ChooseDeviceActivity.EXTRA_DEVICE_ADDRESS);
                BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
                //Toast.makeText(this, address, Toast.LENGTH_LONG).show();
                mDeviceAddress = address;
                mNXTTalker.connect(device);
            }
            break;
        case REQUEST_SETTINGS:
            if (resultCode == Activity.RESULT_OK) {
                int maxPower = Integer.parseInt(data.getExtras().getString(SettingsActivity.MAX_POWER));
                if (maxPower > 0 && maxPower <= 100) {
                    mNXTTalker.setCtrlValue(100 + maxPower, 1);
                }
            }
            break;
        case REQUEST_LIGHT:
            if (resultCode == Activity.RESULT_OK) {
                int light = Integer.parseInt(data.getExtras().getString(LightActivity.LIGHT_SETTING));
                if (light > 0 && light <= 3) {
                    mNXTTalker.setCtrlValue(200 + light, 1);
                }
            }
            break;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //Log.i("NXT", "NXTRemoteControl.onSaveInstanceState()");
        if (mState == NXTTalker.STATE_CONNECTED) {
            outState.putString("device_address", mDeviceAddress);
        }
        //outState.putBoolean("reverse", mReverse);
        outState.putInt("power", mPower);
        outState.putInt("controls_mode", mControlsMode);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //Log.i("NXT", "NXTRemoteControl.onConfigurationChanged()");
        setupUI();
    }
    
    private void displayState() {
        String stateText = null;
        int color = 0;
        
        switch (mState){ 
        case NXTTalker.STATE_NONE:
            stateText = "Not connected";
            color = 0xffff0000;
            setProgressBarIndeterminateVisibility(false);
            break;
        case NXTTalker.STATE_CONNECTING:
            stateText = "Connecting...";
            color = 0xffffff00;
            setProgressBarIndeterminateVisibility(true);
            break;
        case NXTTalker.STATE_CONNECTED:
            stateText = "Connected";
            color = 0xff00ff00;
            setProgressBarIndeterminateVisibility(false);
            break;
        }
        mStateDisplay.setText(stateText);
        mStateDisplay.setTextColor(color);
    }

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST), Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_STATE_CHANGE:
                mState = msg.arg1;
                displayState();
                break;
            }
        }
    };

    @Override
    protected void onStop() {
        super.onStop();
        mSavedState = mState;
        mNXTTalker.stop();
        if (fos != null) {
            try {
                fos.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                fos = null;
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        mMenu = menu;
        return true;
    }
    
    // 菜单被显示之前的事件
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        mBluetoothMenu = (MenuItem) menu.findItem(R.id.menuitem_bluetooth);
        //mBluetoothMenu.setEnabled(mState != NXTTalker.STATE_CONNECTING);

        switch (mState){ 
            case NXTTalker.STATE_NONE:
                mBluetoothMenu.setTitle("Connect");
                break;
            case NXTTalker.STATE_CONNECTING:
                mBluetoothMenu.setTitle("Waiting");
                break;
            case NXTTalker.STATE_CONNECTED:
                mBluetoothMenu.setTitle("Disconnect");
                break;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case R.id.menuitem_buttons:
            mControlsMode = MODE_BUTTONS;
            setupUI();
            break;
        case R.id.menuitem_settings:
            if (mState == NXTTalker.STATE_CONNECTED) {
                Intent i = new Intent(this, SettingsActivity.class);
                startActivityForResult(i, REQUEST_SETTINGS);
            } else {
                findBrick();
            }
            break;
        case R.id.menuitem_light:
            if (mState == NXTTalker.STATE_CONNECTED) {
                Intent i = new Intent(this, LightActivity.class);
                startActivityForResult(i, REQUEST_LIGHT);
            } else {
                findBrick();
            }
            break;
        case R.id.menuitem_bluetooth:
            if (item.getTitle().equals("Connect")) {
                if (!NO_BT) {
                    findBrick();
                } else {
                    mState = NXTTalker.STATE_CONNECTED;
                    displayState();
                }
            } else if (item.getTitle().equals("Disconnect")) {
                mNXTTalker.stop();
            }
            break;
        case R.id.menuitem_horn:
            mNXTTalker.setCtrlValue(204, 1);
            break;
        default:
            return false;    
        }
        return true;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        readPreferences(sharedPreferences, key);
    }
    
    private void readPreferences(SharedPreferences prefs, String key) {
    }
}
